# SnapDisplay - Virtual Second Monitor (Extended Desktop)

Turn any Android phone or tablet into a genuine secondary monitor for Windows!

---

## 🚀 How to Enable (1-Click)

1. Right-click `enable-second-monitor.bat` and click **Run as administrator** (or just double-click it and click **Yes** on the UAC prompt).
2. The script will:
   - Configure the virtual display resolution (1080p 60Hz)
   - Install the virtual display device driver into Windows Device Manager
   - Open **Windows Display Settings**
3. In Windows Display Settings, you will see two displays:
   ```
   [ 1 ]       [ 2 ]
   ```
4. Make sure **"Multiple displays"** is set to **"Extend these displays"**.
5. Return to **SnapDisplay** in your browser:
   - Click **`🖥️ Virtual Second Monitor`**
   - Click **`🚀 Stream Extended Display (Screen 2) to Phone`**
   - In the browser prompt, select **Screen 2** (the virtual monitor).
6. Done! Drag any window from your PC past the right edge of your monitor—it will smoothly glide right onto your phone screen!

---

## 🛑 How to Disable / Remove

Whenever you are done and want Windows to return to single-monitor mode:
- Double-click `disable-second-monitor.bat` (click Yes on UAC).
- Windows will immediately remove `Display 2`.
