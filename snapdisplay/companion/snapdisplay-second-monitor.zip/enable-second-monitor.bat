@echo off
setlocal
cd /d "%~dp0"
title SnapDisplay Companion
if exist "%~dp0SnapDisplay-Companion.exe" (
    start "" "%~dp0SnapDisplay-Companion.exe"
    exit /b
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0enable-second-monitor.ps1"
