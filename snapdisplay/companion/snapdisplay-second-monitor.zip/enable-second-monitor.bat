@echo off
setlocal
cd /d "%~dp0"
title SnapDisplay - Virtual Second Monitor Activator
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0enable-second-monitor.ps1"
if %errorlevel% neq 0 (
    echo.
    echo If powershell closed unexpectedly, please right-click enable-second-monitor.bat and select 'Run as Administrator'.
    pause
)
