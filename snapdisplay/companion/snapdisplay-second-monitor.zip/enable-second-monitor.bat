@echo off
setlocal enabledelayedexpansion
title SnapDisplay - 1-Click Virtual Second Monitor Activator
color 0b

:: Check for Administrator permissions
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Requesting Administrator permissions...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

echo ======================================================================
echo             SnapDisplay - Virtual Second Monitor Activator
echo ======================================================================
echo.

set "DRIVER_DIR=%~dp0driver"

:: If local driver folder does not exist (e.g. running from Downloads), fetch package
if not exist "!DRIVER_DIR!\nefconc.exe" (
    echo [INFO] Local driver folder not found. Downloading companion package...
    set "TEMP_DIR=%TEMP%\SnapDisplayVDD"
    if not exist "!TEMP_DIR!" mkdir "!TEMP_DIR!" >nul 2>&1
    
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
        "$ErrorActionPreference = 'Stop';" ^
        "$zip = Join-Path $env:TEMP 'SnapDisplayVDD\companion.zip';" ^
        "$dest = Join-Path $env:TEMP 'SnapDisplayVDD\extracted';" ^
        "Write-Host '   Downloading driver package from SnapDisplay repository...';" ^
        "Invoke-WebRequest -Uri 'https://sajusun.github.io/extensions/snapdisplay/companion/snapdisplay-second-monitor.zip' -OutFile $zip -UseBasicParsing;" ^
        "Write-Host '   Extracting driver files...';" ^
        "Expand-Archive -Path $zip -DestinationPath $dest -Force;"
    
    if exist "%TEMP%\SnapDisplayVDD\extracted\driver\nefconc.exe" (
        set "DRIVER_DIR=%TEMP%\SnapDisplayVDD\extracted\driver"
        echo    Driver package ready.
    ) else (
        echo [ERROR] Failed to obtain driver package. Please check internet connection.
        pause
        exit /b 1
    )
)

echo.
echo [1/4] Preparing Virtual Display Configuration...
if not exist "C:\Virtual-Display-Driver" mkdir "C:\Virtual-Display-Driver" >nul 2>&1
copy /y "!DRIVER_DIR!\vdd_settings.xml" "C:\Virtual-Display-Driver\vdd_settings.xml" >nul 2>&1

echo [2/4] Registering security certificates in Windows...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$cat = '!DRIVER_DIR!\mttvdd.cat';" ^
    "if (Test-Path $cat) {" ^
    "  $bytes = [System.IO.File]::ReadAllBytes($cat);" ^
    "  $certs = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection;" ^
    "  $certs.Import($bytes);" ^
    "  foreach ($c in $certs) {" ^
    "    $tmp = [System.IO.Path]::Combine($env:TEMP, ($c.Thumbprint + '.cer'));" ^
    "    [System.IO.File]::WriteAllBytes($tmp, $c.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert));" ^
    "    Import-Certificate -FilePath $tmp -CertStoreLocation 'Cert:\LocalMachine\TrustedPublisher' -ErrorAction SilentlyContinue | Out-Null;" ^
    "    Import-Certificate -FilePath $tmp -CertStoreLocation 'Cert:\LocalMachine\Root' -ErrorAction SilentlyContinue | Out-Null;" ^
    "    Remove-Item $tmp -Force -ErrorAction SilentlyContinue;" ^
    "  }" ^
    "  Write-Host '   Certificates registered successfully.' -ForegroundColor Green;" ^
    "}"

echo [3/4] Installing Virtual Display Driver into Windows...
"!DRIVER_DIR!\nefconc.exe" install "!DRIVER_DIR!\MttVDD.inf" "Root\MttVDD"
set "INSTALL_STATUS=%errorlevel%"

echo.
echo [4/4] Verifying Virtual Display Device status...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$dev = Get-PnpDevice -HardwareID 'Root\MttVDD' -ErrorAction SilentlyContinue;" ^
    "if ($dev -and $dev.Status -eq 'OK') {" ^
    "  Write-Host '   [VERIFIED] Virtual Display Device is ONLINE and ACTIVE!' -ForegroundColor Green;" ^
    "  exit 0;" ^
    "} else {" ^
    "  Write-Host '   Device state:' ($dev.Status) -ForegroundColor Yellow;" ^
    "  exit 0;" ^
    "}"

echo.
echo Launching Windows Display Settings...
start ms-settings:display

echo.
echo ======================================================================
echo                        [SUCCESSFULLY ACTIVATED!]
echo.
echo 1. In Windows Display Settings, you will now see:
echo                 [ 1 ]       [ 2 ]
echo.
echo 2. Make sure Multiple displays is set to "Extend these displays".
echo 3. Return to SnapDisplay in your browser and click:
echo    "Stream Extended Display (Screen 2) to Phone"
echo ======================================================================
echo.
pause
