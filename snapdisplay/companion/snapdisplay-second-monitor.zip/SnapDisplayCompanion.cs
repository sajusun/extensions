using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;

namespace SnapDisplayCompanion
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Double check elevation if launched directly without manifest
            if (!IsAdministrator())
            {
                try
                {
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = Application.ExecutablePath;
                    psi.Verb = "runas";
                    psi.UseShellExecute = true;
                    Process.Start(psi);
                }
                catch
                {
                    MessageBox.Show(
                        "Administrator privileges are required to manage Windows Virtual Display Drivers.\nPlease right-click SnapDisplay-Companion.exe and choose 'Run as administrator'.",
                        "SnapDisplay Administrator Permission",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }
                return;
            }

            Application.Run(new MainForm());
        }

        private static bool IsAdministrator()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
    }

    public class MainForm : Form
    {
        private Label lblTitle;
        private Label lblSubtitle;
        private Panel panelStatus;
        private Label lblStatusDot;
        private Label lblStatusText;
        private Label lblStatusSub;
        private Button btnActivate;
        private Button btnDeactivate;
        private Button btnSettings;
        private Button btnHelp;
        private TextBox txtLog;
        private Label lblFooter;
        private System.Windows.Forms.Timer statusTimer;

        private readonly Color bgMain = Color.FromArgb(15, 23, 42);      // #0f172a
        private readonly Color bgCard = Color.FromArgb(30, 41, 59);      // #1e293b
        private readonly Color textWhite = Color.FromArgb(248, 250, 252);// #f8fafc
        private readonly Color textDim = Color.FromArgb(148, 163, 184);  // #94a3b8
        private readonly Color btnPrimary = Color.FromArgb(2, 132, 199); // #0284c7
        private readonly Color btnDanger = Color.FromArgb(225, 29, 72);  // #e11d48
        private readonly Color btnSlate = Color.FromArgb(51, 65, 85);    // #334155
        private readonly Color statusGreen = Color.FromArgb(34, 197, 94);// #22c55e

        public MainForm()
        {
            InitializeComponent();
            RefreshDisplayStatus();

            statusTimer = new System.Windows.Forms.Timer();
            statusTimer.Interval = 2500;
            statusTimer.Tick += (s, e) => RefreshDisplayStatus();
            statusTimer.Start();
        }

        private void InitializeComponent()
        {
            this.Text = "SnapDisplay Companion - Virtual Second Monitor";
            this.Size = new Size(540, 520);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = bgMain;
            this.ForeColor = textWhite;
            this.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);

            // Title
            lblTitle = new Label();
            lblTitle.Text = "🖥️ SnapDisplay Companion";
            lblTitle.Font = new Font("Segoe UI", 16f, FontStyle.Bold);
            lblTitle.ForeColor = textWhite;
            lblTitle.Location = new Point(24, 18);
            lblTitle.AutoSize = true;

            lblSubtitle = new Label();
            lblSubtitle.Text = "Windows Virtual Second Monitor Controller (IddCx Architecture)";
            lblSubtitle.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            lblSubtitle.ForeColor = textDim;
            lblSubtitle.Location = new Point(26, 52);
            lblSubtitle.AutoSize = true;

            // Status Card
            panelStatus = new Panel();
            panelStatus.Location = new Point(24, 85);
            panelStatus.Size = new Size(476, 75);
            panelStatus.BackColor = bgCard;

            lblStatusDot = new Label();
            lblStatusDot.Text = "●";
            lblStatusDot.Font = new Font("Segoe UI", 16f, FontStyle.Bold);
            lblStatusDot.Location = new Point(14, 18);
            lblStatusDot.Size = new Size(25, 30);

            lblStatusText = new Label();
            lblStatusText.Text = "Checking Windows Display status...";
            lblStatusText.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            lblStatusText.ForeColor = textWhite;
            lblStatusText.Location = new Point(44, 14);
            lblStatusText.Size = new Size(415, 24);

            lblStatusSub = new Label();
            lblStatusSub.Text = "Detecting displays and driver state...";
            lblStatusSub.Font = new Font("Segoe UI", 9f, FontStyle.Regular);
            lblStatusSub.ForeColor = textDim;
            lblStatusSub.Location = new Point(45, 40);
            lblStatusSub.Size = new Size(415, 22);

            panelStatus.Controls.Add(lblStatusDot);
            panelStatus.Controls.Add(lblStatusText);
            panelStatus.Controls.Add(lblStatusSub);

            // Activate Button
            btnActivate = new Button();
            btnActivate.Text = "⚡ Activate Virtual Display (Screen 2)";
            btnActivate.Location = new Point(24, 175);
            btnActivate.Size = new Size(232, 44);
            btnActivate.BackColor = btnPrimary;
            btnActivate.ForeColor = Color.White;
            btnActivate.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnActivate.FlatStyle = FlatStyle.Flat;
            btnActivate.FlatAppearance.BorderSize = 0;
            btnActivate.Cursor = Cursors.Hand;
            btnActivate.Click += BtnActivate_Click;

            // Deactivate Button
            btnDeactivate = new Button();
            btnDeactivate.Text = "❌ Turn Off Virtual Display";
            btnDeactivate.Location = new Point(268, 175);
            btnDeactivate.Size = new Size(232, 44);
            btnDeactivate.BackColor = btnDanger;
            btnDeactivate.ForeColor = Color.White;
            btnDeactivate.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            btnDeactivate.FlatStyle = FlatStyle.Flat;
            btnDeactivate.FlatAppearance.BorderSize = 0;
            btnDeactivate.Cursor = Cursors.Hand;
            btnDeactivate.Click += BtnDeactivate_Click;

            // Windows Settings Button
            btnSettings = new Button();
            btnSettings.Text = "⚙️ Open Windows Display Settings";
            btnSettings.Location = new Point(24, 230);
            btnSettings.Size = new Size(232, 36);
            btnSettings.BackColor = btnSlate;
            btnSettings.ForeColor = textWhite;
            btnSettings.FlatStyle = FlatStyle.Flat;
            btnSettings.FlatAppearance.BorderSize = 0;
            btnSettings.Cursor = Cursors.Hand;
            btnSettings.Click += (s, e) => OpenUrl("ms-settings:display");

            // Help & Guide Button
            btnHelp = new Button();
            btnHelp.Text = "🛡️ Verification & Setup Guide";
            btnHelp.Location = new Point(268, 230);
            btnHelp.Size = new Size(232, 36);
            btnHelp.BackColor = btnSlate;
            btnHelp.ForeColor = textWhite;
            btnHelp.FlatStyle = FlatStyle.Flat;
            btnHelp.FlatAppearance.BorderSize = 0;
            btnHelp.Cursor = Cursors.Hand;
            btnHelp.Click += (s, e) => OpenUrl("https://sajusun.github.io/extensions/snapdisplay/companion/");

            // Log Console
            txtLog = new TextBox();
            txtLog.Location = new Point(24, 280);
            txtLog.Size = new Size(476, 140);
            txtLog.Multiline = true;
            txtLog.ReadOnly = true;
            txtLog.ScrollBars = ScrollBars.Vertical;
            txtLog.BackColor = Color.FromArgb(10, 15, 29);
            txtLog.ForeColor = Color.FromArgb(203, 213, 225);
            txtLog.Font = new Font("Consolas", 9f);
            txtLog.BorderStyle = BorderStyle.FixedSingle;
            txtLog.Text = "SnapDisplay Companion v1.2.0 initialized.\r\nReady. Click 'Activate' to attach a virtual 1080p 60Hz display to Windows.\r\n";

            // Footer
            lblFooter = new Label();
            lblFooter.Text = "🔒 Microsoft IddCx Virtual Display Driver • 100% Offline & Private • Zero Lag";
            lblFooter.Font = new Font("Segoe UI", 8.5f, FontStyle.Regular);
            lblFooter.ForeColor = textDim;
            lblFooter.Location = new Point(24, 435);
            lblFooter.Size = new Size(476, 20);
            lblFooter.TextAlign = ContentAlignment.MiddleCenter;

            // Add Controls to Form
            this.Controls.Add(lblTitle);
            this.Controls.Add(lblSubtitle);
            this.Controls.Add(panelStatus);
            this.Controls.Add(btnActivate);
            this.Controls.Add(btnDeactivate);
            this.Controls.Add(btnSettings);
            this.Controls.Add(btnHelp);
            this.Controls.Add(txtLog);
            this.Controls.Add(lblFooter);
        }

        private void AppendLog(string message)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new Action<string>(AppendLog), message);
                return;
            }
            txtLog.AppendText(string.Format("[{0:HH:mm:ss}] {1}\r\n", DateTime.Now, message));
            txtLog.SelectionStart = txtLog.Text.Length;
            txtLog.ScrollToCaret();
        }

        private void RefreshDisplayStatus()
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(RefreshDisplayStatus));
                return;
            }

            int screenCount = Screen.AllScreens.Length;
            bool multipleDisplays = screenCount > 1;

            if (multipleDisplays)
            {
                lblStatusDot.ForeColor = statusGreen;
                lblStatusText.Text = string.Format("Multiple Displays Active ({0} Displays Detected)", screenCount);
                lblStatusSub.Text = "Windows Extended Desktop is ready! Select 'Screen 2' in SnapDisplay.";
                btnActivate.Enabled = false;
                btnActivate.BackColor = Color.FromArgb(71, 85, 105);
                btnDeactivate.Enabled = true;
                btnDeactivate.BackColor = btnDanger;
            }
            else
            {
                lblStatusDot.ForeColor = Color.FromArgb(234, 179, 8); // Yellow
                lblStatusText.Text = "Single Display (Virtual Monitor Inactive)";
                lblStatusSub.Text = "Click 'Activate Virtual Display' to add Display 2 to Windows.";
                btnActivate.Enabled = true;
                btnActivate.BackColor = btnPrimary;
                btnDeactivate.Enabled = true;
                btnDeactivate.BackColor = btnSlate;
            }
        }

        private void BtnActivate_Click(object sender, EventArgs e)
        {
            btnActivate.Enabled = false;
            btnDeactivate.Enabled = false;
            AppendLog("Starting Virtual Second Monitor activation...");

            ThreadPool.QueueUserWorkItem((state) =>
            {
                try
                {
                    string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                    string driverDir = Path.Combine(baseDir, "driver");

                    // 1. Prepare C:\Virtual-Display-Driver\vdd_settings.xml
                    AppendLog("Configuring display EDID and resolutions...");
                    string targetDir = @"C:\Virtual-Display-Driver";
                    if (!Directory.Exists(targetDir))
                    {
                        Directory.CreateDirectory(targetDir);
                    }
                    string xmlDest = Path.Combine(targetDir, "vdd_settings.xml");
                    string xmlSrc = Path.Combine(driverDir, "vdd_settings.xml");
                    if (File.Exists(xmlSrc))
                    {
                        File.Copy(xmlSrc, xmlDest, true);
                    }
                    else
                    {
                        string defaultXml = "<?xml version='1.0' encoding='utf-8'?>\n<vdd_settings>\n  <monitors><count>1</count></monitors>\n  <gpu><friendlyname>default</friendlyname></gpu>\n  <global><g_refresh_rate>60</g_refresh_rate><g_refresh_rate>90</g_refresh_rate><g_refresh_rate>120</g_refresh_rate></global>\n  <resolutions>\n    <resolution><width>1920</width><height>1080</height><refresh_rate>60</refresh_rate></resolution>\n    <resolution><width>1366</width><height>768</height><refresh_rate>60</refresh_rate></resolution>\n    <resolution><width>1280</width><height>720</height><refresh_rate>60</refresh_rate></resolution>\n  </resolutions>\n  <options><HardwareCursor>true</HardwareCursor></options>\n</vdd_settings>";
                        File.WriteAllText(xmlDest, defaultXml);
                    }
                    AppendLog("Target settings stored at C:\\Virtual-Display-Driver\\vdd_settings.xml");

                    // 2. Import Security Certificates
                    string catPath = Path.Combine(driverDir, "mttvdd.cat");
                    if (File.Exists(catPath))
                    {
                        AppendLog("Trusting driver security certificates...");
                        try
                        {
                            X509Certificate2Collection certs = new X509Certificate2Collection();
                            certs.Import(catPath);

                            using (X509Store storePub = new X509Store(StoreName.TrustedPublisher, StoreLocation.LocalMachine))
                            {
                                storePub.Open(OpenFlags.ReadWrite);
                                foreach (X509Certificate2 cert in certs)
                                {
                                    storePub.Add(cert);
                                }
                                storePub.Close();
                            }

                            using (X509Store storeRoot = new X509Store(StoreName.Root, StoreLocation.LocalMachine))
                            {
                                storeRoot.Open(OpenFlags.ReadWrite);
                                foreach (X509Certificate2 cert in certs)
                                {
                                    storeRoot.Add(cert);
                                }
                                storeRoot.Close();
                            }
                            AppendLog("Certificates installed to Trusted Publisher store.");
                        }
                        catch (Exception certEx)
                        {
                            AppendLog("Cert note: " + certEx.Message);
                        }
                    }

                    // 3. Stage driver with pnputil
                    string infPath = Path.Combine(driverDir, "MttVDD.inf");
                    if (File.Exists(infPath))
                    {
                        AppendLog("Staging MttVDD.inf with pnputil...");
                        RunSilentCommand("pnputil.exe", string.Format("/add-driver \"{0}\" /install", infPath));
                    }

                    // 4. Create or refresh device node with nefconc.exe
                    string nefconPath = Path.Combine(driverDir, "nefconc.exe");
                    if (File.Exists(nefconPath) && File.Exists(infPath))
                    {
                        AppendLog("Creating virtual display hardware device (Root\\MttVDD)...");
                        RunSilentCommand(nefconPath, string.Format("install \"{0}\" Root\\MttVDD", infPath));
                    }
                    else
                    {
                        AppendLog("Notice: nefconc.exe not found at: " + nefconPath);
                    }

                    AppendLog("Waiting 3 seconds for Windows DWM display topology initialization...");
                    Thread.Sleep(3000);

                    AppendLog("SUCCESS! Virtual Second Monitor is active.");
                    AppendLog("Opening Windows Display Settings...");
                    OpenUrl("ms-settings:display");
                }
                catch (Exception ex)
                {
                    AppendLog("ERROR: " + ex.Message);
                }
                finally
                {
                    this.Invoke(new Action(() =>
                    {
                        RefreshDisplayStatus();
                    }));
                }
            });
        }

        private void BtnDeactivate_Click(object sender, EventArgs e)
        {
            btnActivate.Enabled = false;
            btnDeactivate.Enabled = false;
            AppendLog("Removing Virtual Display Device node...");

            ThreadPool.QueueUserWorkItem((state) =>
            {
                try
                {
                    string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                    string nefconPath = Path.Combine(baseDir, "driver", "nefconc.exe");

                    if (File.Exists(nefconPath))
                    {
                        RunSilentCommand(nefconPath, "--remove-device-node --hardware-id Root\\MttVDD --class-guid {4D36E968-E325-11CE-BFC1-08002BE10318}");
                    }
                    else
                    {
                        // Fallback via pnputil
                        RunSilentCommand("pnputil.exe", "/remove-device \"Root\\MttVDD\"");
                    }

                    Thread.Sleep(2000);
                    AppendLog("SUCCESS: Virtual Second Monitor removed from Windows.");
                }
                catch (Exception ex)
                {
                    AppendLog("ERROR while disabling: " + ex.Message);
                }
                finally
                {
                    this.Invoke(new Action(() =>
                    {
                        RefreshDisplayStatus();
                    }));
                }
            });
        }

        private string RunSilentCommand(string fileName, string args)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = fileName;
                psi.Arguments = args;
                psi.CreateNoWindow = true;
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                using (Process proc = Process.Start(psi))
                {
                    string output = proc.StandardOutput.ReadToEnd();
                    proc.WaitForExit(10000);
                    return output;
                }
            }
            catch (Exception ex)
            {
                AppendLog("Cmd error: " + ex.Message);
                return string.Empty;
            }
        }

        private void OpenUrl(string url)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = url;
                psi.UseShellExecute = true;
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                AppendLog("Could not open link: " + ex.Message);
            }
        }
    }
}
