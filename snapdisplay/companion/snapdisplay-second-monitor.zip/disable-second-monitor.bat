@echo off
setlocal enabledelayedexpansion
title SnapDisplay - Remove Virtual Second Monitor
color 0c

:: Check for Administrator permissions
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Requesting Administrator permissions...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/k \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

echo ======================================================================
echo              SnapDisplay - Virtual Monitor Remover
echo ======================================================================
echo.

set "DRIVER_DIR=%~dp0driver"
if not exist "!DRIVER_DIR!\nefconc.exe" (
    set "DRIVER_DIR=%TEMP%\SnapDisplayVDD\extracted\driver"
)

if exist "!DRIVER_DIR!\nefconc.exe" (
    echo Removing Virtual Display Driver device node...
    "!DRIVER_DIR!\nefconc.exe" --remove-device-node --hardware-id "Root\MttVDD" --class-guid "{4D36E968-E325-11CE-BFC1-08002BE10318}"
) else (
    echo Removing Virtual Display Driver device node via Windows PnPUtil...
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
        "$dev = Get-PnpDevice -HardwareID 'Root\MttVDD' -ErrorAction SilentlyContinue;" ^
        "if ($dev) {" ^
        "  & pnputil /remove-device $dev.InstanceId;" ^
        "  Write-Host '   Device removed successfully.' -ForegroundColor Green;" ^
        "} else {" ^
        "  Write-Host '   No active Virtual Display Device found.' -ForegroundColor Yellow;" ^
        "}"
)

echo.
echo ======================================================================
echo [SUCCESS] Virtual Monitor removed. Windows is back to single screen.
echo ======================================================================
echo.
pause
